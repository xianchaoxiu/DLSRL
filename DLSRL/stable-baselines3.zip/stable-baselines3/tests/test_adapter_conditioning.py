import numpy as np
import torch as th
from gymnasium import spaces

from stable_baselines3.sac.policies import SACPolicy


def make_adapter_actor():
    th.manual_seed(0)
    observation_space = spaces.Box(-1.0, 1.0, shape=(5,), dtype=np.float32)
    action_space = spaces.Box(-1.0, 1.0, shape=(11,), dtype=np.float32)
    policy = SACPolicy(
        observation_space,
        action_space,
        lr_schedule=lambda _: 3e-4,
        net_arch=[16],
        standard_gauss_init=True,
        adapter_kwargs={
            "enabled": True,
            "latent_steps": 1,
            "noise_steps": 2,
            "noise_dim": 3,
            "control_dim": 4,
            "gate_dim": 1,
            "feature_dim": 8,
            "hidden_dim": 8,
            "feature_init_std": 0.1,
            "feature_scale": 0.25,
            "gate_max": 0.2,
            "gate_logit_scale": 5.0,
            "gate_logit_bias": -2.5,
            "injection_scale": 0.05,
            "critic_effect_scale": 20.0,
        },
    )
    return policy.actor


def test_critic_adapter_action_matches_transformer_injection_scale():
    actor = make_adapter_actor()
    actor.set_adapter_runtime_scale(0.4)
    action = th.zeros(2, 11)
    action[:, 6:10] = 0.5
    action[:, 10] = 0.25

    noise, adapter_feature, adapter_gate = actor.pack_adapter_action(action)
    effective_delta = actor.adapter_injection_scale * adapter_gate * th.tanh(adapter_feature)
    critic_delta = actor.adapter_critic_effect_scale * effective_delta
    expected_summary = critic_delta.reshape(2, 1, 4, 2).mean(dim=-1).reshape(2, -1)
    expected_strength = th.linalg.vector_norm(critic_delta, dim=-1) / np.sqrt(8)

    critic_action = actor.critic_adapter_action(action)
    th.testing.assert_close(critic_action[:, :6], noise.reshape(2, -1))
    th.testing.assert_close(critic_action[:, 6:10], expected_summary)
    th.testing.assert_close(critic_action[:, 10:], expected_strength)


def test_gate_regularization_is_not_weakened_by_runtime_ramp():
    actor = make_adapter_actor()
    action = th.zeros(2, 11)
    action[:, 6:10] = 0.5
    action[:, 10] = 0.25

    actor.set_adapter_runtime_scale(0.0)
    _, gate_l1_at_zero, _, gate_mean_at_zero, delta_norm_at_zero = actor.adapter_regularization(action)
    actor.set_adapter_runtime_scale(1.0)
    _, gate_l1_at_one, _, gate_mean_at_one, delta_norm_at_one = actor.adapter_regularization(action)

    th.testing.assert_close(gate_l1_at_zero, gate_l1_at_one)
    th.testing.assert_close(gate_mean_at_zero, th.zeros_like(gate_mean_at_zero))
    th.testing.assert_close(delta_norm_at_zero, th.zeros_like(delta_norm_at_zero))
    assert gate_mean_at_one.item() > 0.0
    assert delta_norm_at_one.item() > 0.0


def test_per_token_adapter_controls_remain_distinct():
    observation_space = spaces.Box(-1.0, 1.0, shape=(5,), dtype=np.float32)
    action_space = spaces.Box(-1.0, 1.0, shape=(26,), dtype=np.float32)
    policy = SACPolicy(
        observation_space,
        action_space,
        lr_schedule=lambda _: 3e-4,
        net_arch=[16],
        standard_gauss_init=True,
        adapter_kwargs={
            "enabled": True,
            "latent_steps": 4,
            "noise_steps": 2,
            "noise_dim": 3,
            "control_dim": 4,
            "gate_dim": 1,
            "feature_dim": 8,
            "hidden_dim": 8,
            "feature_init_std": 0.1,
            "feature_scale": 0.25,
            "gate_max": 0.2,
            "gate_logit_scale": 5.0,
            "gate_logit_bias": -2.5,
            "injection_scale": 0.03,
            "critic_effect_scale": 100.0,
        },
    )
    actor = policy.actor
    action = th.zeros(2, 26)
    action[:, 6:22] = th.arange(16, dtype=th.float32).reshape(1, 16) / 16
    action[:, 22:26] = th.tensor([[0.0, 0.2, 0.4, 0.6]])

    _, feature, gate = actor.pack_adapter_action(action)
    critic_action = actor.critic_adapter_action(action)

    assert feature.shape == (2, 4, 8)
    assert gate.shape == (2, 4, 1)
    assert critic_action.shape == (2, 26)
    assert not th.allclose(feature[:, 0], feature[:, 1])
    assert not th.allclose(gate[:, 0], gate[:, 1])
