from typing import Any, ClassVar, Optional, TypeVar, Union

import numpy as np
import torch as th
from gymnasium import spaces
from torch.nn import functional as F

from stable_baselines3.common.buffers import ReplayBuffer
from stable_baselines3.common.noise import ActionNoise
from stable_baselines3.common.off_policy_algorithm import OffPolicyAlgorithm
from stable_baselines3.common.policies import BasePolicy, ContinuousCritic
from stable_baselines3.common.type_aliases import GymEnv, MaybeCallback, Schedule
from stable_baselines3.common.utils import get_parameters_by_name, polyak_update
from stable_baselines3.sac.policies import Actor, CnnPolicy, MlpPolicy, MultiInputPolicy, SACPolicy

from stable_baselines3.common.type_aliases import GymEnv, MaybeCallback, RolloutReturn, Schedule, TrainFreq, TrainFrequencyUnit
from stable_baselines3.common.utils import safe_mean, should_collect_more_steps
from stable_baselines3.common.vec_env import VecEnv

SelfDSRL = TypeVar("SelfDSRL", bound="DSRL")


class DSRL(OffPolicyAlgorithm):
	"""
	DSRL-NA (noise aliased variant of DSRL)
	Based on the SAC implementation in Stable Baselines3.
	Paper: https://arxiv.org/pdf/2506.15799

	:param policy: The policy model to use (MlpPolicy, CnnPolicy, ...)
	:param env: The environment to learn from (if registered in Gym, can be str)
	:param learning_rate: learning rate for adam optimizer,
		the same learning rate will be used for all networks (Q-Values, Actor and Value function)
		it can be a function of the current progress remaining (from 1 to 0)
	:param buffer_size: size of the replay buffer
	:param learning_starts: how many steps of the model to collect transitions for before learning starts
	:param batch_size: Minibatch size for each gradient update
	:param tau: the soft update coefficient ("Polyak update", between 0 and 1)
	:param gamma: the discount factor
	:param train_freq: Update the model every ``train_freq`` steps. Alternatively pass a tuple of frequency and unit
		like ``(5, "step")`` or ``(2, "episode")``.
	:param gradient_steps: How many gradient steps to do after each rollout (see ``train_freq``)
		Set to ``-1`` means to do as many gradient steps as steps done in the environment
		during the rollout.
	:param action_noise: the action noise type (None by default), this can help
		for hard exploration problem. Cf common.noise for the different action noise type.
	:param replay_buffer_class: Replay buffer class to use (for instance ``HerReplayBuffer``).
		If ``None``, it will be automatically selected.
	:param replay_buffer_kwargs: Keyword arguments to pass to the replay buffer on creation.
	:param optimize_memory_usage: Enable a memory efficient variant of the replay buffer
		at a cost of more complexity.
		See https://github.com/DLR-RM/stable-baselines3/issues/37#issuecomment-637501195
	:param ent_coef: Entropy regularization coefficient. (Equivalent to
		inverse of reward scale in the original SAC paper.)  Controlling exploration/exploitation trade-off.
		Set it to 'auto' to learn it automatically (and 'auto_0.1' for using 0.1 as initial value)
	:param target_update_interval: update the target network every ``target_network_update_freq``
		gradient steps.
	:param target_entropy: target entropy when learning ``ent_coef`` (``ent_coef = 'auto'``)
	:param use_sde: Whether to use generalized State Dependent Exploration (gSDE)
		instead of action noise exploration (default: False)
	:param sde_sample_freq: Sample a new noise matrix every n steps when using gSDE
		Default: -1 (only sample at the beginning of the rollout)
	:param use_sde_at_warmup: Whether to use gSDE instead of uniform sampling
		during the warm up phase (before learning starts)
	:param stats_window_size: Window size for the rollout logging, specifying the number of episodes to average
		the reported success rate, mean episode length, and mean reward over
	:param tensorboard_log: the log location for tensorboard (if None, no logging)
	:param policy_kwargs: additional arguments to be passed to the policy on creation. See :ref:`sac_policies`
	:param verbose: Verbosity level: 0 for no output, 1 for info messages (such as device or wrappers used), 2 for
		debug messages
	:param seed: Seed for the pseudo random generators
	:param device: Device (cpu, cuda, ...) on which the code should be run.
		Setting it to auto, the code will be run on the GPU if possible.
	:param _init_setup_model: Whether or not to build the network at the creation of the instance
	:param actor_gradient_steps: Number of gradient steps to take on actor per training update
	:param diffusion_policy: The diffusion policy to use for action generation
	:param diffusion_act_dim: The action dimension for the diffusion policy (tuple of (action chunk length, action_dim))
	:param noise_critic_grad_steps: Number of gradient steps to take on distilled noise critic per training update
	:param critic_backup_combine_type: How to combine the critics for the backup (min or mean)
	"""
	policy_aliases: ClassVar[dict[str, type[BasePolicy]]] = {
		"MlpPolicy": MlpPolicy,
		"CnnPolicy": CnnPolicy,
		"MultiInputPolicy": MultiInputPolicy,
	}
	policy: SACPolicy
	actor: Actor
	critic: ContinuousCritic
	critic_target: ContinuousCritic
	critic_noise: ContinuousCritic

	def __init__(
		self,
		policy: Union[str, type[SACPolicy]],
		env: Union[GymEnv, str],
		learning_rate: Union[float, Schedule] = 3e-4,
		buffer_size: int = 1_000_000,  # 1e6
		learning_starts: int = 100,
		batch_size: int = 256,
		tau: float = 0.005,
		gamma: float = 0.99,
		train_freq: Union[int, tuple[int, str]] = 1,
		gradient_steps: int = 1,
		action_noise: Optional[ActionNoise] = None,
		replay_buffer_class: Optional[type[ReplayBuffer]] = None,
		replay_buffer_kwargs: Optional[dict[str, Any]] = None,
		optimize_memory_usage: bool = False,
		ent_coef: Union[str, float] = "auto",
		target_update_interval: int = 1,
		target_entropy: Union[str, float] = "auto",
		use_sde: bool = False,
		sde_sample_freq: int = -1,
		use_sde_at_warmup: bool = False,
		stats_window_size: int = 100,
		tensorboard_log: Optional[str] = None,
		policy_kwargs: Optional[dict[str, Any]] = None,
		verbose: int = 0,
		seed: Optional[int] = None,
		device: Union[th.device, str] = "auto",
		_init_setup_model: bool = True,
		actor_gradient_steps: int = -1,
		diffusion_policy=None,
		diffusion_act_dim=None,
		noise_critic_grad_steps: int = 1,
		critic_backup_combine_type='min',
		adapter_kwargs: Optional[dict[str, Any]] = None,
		adapter_l2_coef: float = 0.0,
		adapter_gate_l1_coef: float = 0.0,
		adapter_control_l2_coef: float = 0.0,
		adapter_gate_code_l2_coef: float = 0.0,
		action_norm_regularization: float = 0.0,
	):
		super().__init__(
			policy,
			env,
			learning_rate,
			buffer_size,
			learning_starts,
			batch_size,
			tau,
			gamma,
			train_freq,
			gradient_steps,
			action_noise,
			replay_buffer_class=replay_buffer_class,
			replay_buffer_kwargs=replay_buffer_kwargs,
			policy_kwargs=policy_kwargs,
			stats_window_size=stats_window_size,
			tensorboard_log=tensorboard_log,
			verbose=verbose,
			device=device,
			seed=seed,
			use_sde=use_sde,
			sde_sample_freq=sde_sample_freq,
			use_sde_at_warmup=use_sde_at_warmup,
			optimize_memory_usage=optimize_memory_usage,
			supported_action_spaces=(spaces.Box,),
			support_multi_env=True,
		)

		self.target_entropy = target_entropy
		self.log_ent_coef = None  # type: Optional[th.Tensor]
		# Entropy coefficient / Entropy temperature
		# Inverse of the reward scale
		self.ent_coef = ent_coef
		self.target_update_interval = target_update_interval
		self.ent_coef_optimizer: Optional[th.optim.Adam] = None
		self.actor_gradient_steps = actor_gradient_steps
		
		self.diffusion_policy = diffusion_policy
		if diffusion_act_dim is None:
			if _init_setup_model:
				raise ValueError("diffusion_act_dim is required when constructing a new DSRL model.")
			self.diffusion_act_chunk = None
			self.diffusion_act_dim = None
		else:
			self.diffusion_act_chunk = diffusion_act_dim[0]
			self.diffusion_act_dim = diffusion_act_dim[1]
		self.noise_critic_grad_steps = noise_critic_grad_steps
		self.critic_backup_combine_type = critic_backup_combine_type
		self.adapter_kwargs = adapter_kwargs or {}
		self.use_adapter_conditioning = bool(self.adapter_kwargs.get("enabled", False))
		self.adapter_l2_coef = float(adapter_l2_coef)
		self.adapter_gate_l1_coef = float(adapter_gate_l1_coef)
		self.adapter_control_l2_coef = float(adapter_control_l2_coef)
		self.adapter_gate_code_l2_coef = float(adapter_gate_code_l2_coef)
		self.action_norm_regularization = float(action_norm_regularization)
		self.adapter_warmup_steps = int(self.adapter_kwargs.get("warmup_steps", 0))
		self.adapter_ramp_steps = int(self.adapter_kwargs.get("ramp_steps", 0))
		self.adapter_gradient_scale = float(self.adapter_kwargs.get("gradient_scale", 1.0))
		if self.adapter_warmup_steps < 0 or self.adapter_ramp_steps < 0:
			raise ValueError("Adapter warmup_steps and ramp_steps must be non-negative.")
		if not 0.0 <= self.adapter_gradient_scale <= 1.0:
			raise ValueError("Adapter gradient_scale must be in [0, 1].")
		if min(
			self.adapter_l2_coef,
			self.adapter_gate_l1_coef,
			self.adapter_control_l2_coef,
			self.adapter_gate_code_l2_coef,
		) < 0.0:
			raise ValueError("Adapter regularization coefficients must be non-negative.")

		if _init_setup_model:
			self._setup_model()

	def _setup_model(self) -> None:
		super()._setup_model()
		self._create_aliases()
		baseline_actor = self.actor
		# Running mean and running var
		self.batch_norm_stats = get_parameters_by_name(self.critic, ["running_"])
		self.batch_norm_stats_target = get_parameters_by_name(self.critic_target, ["running_"])
		if self.use_adapter_conditioning:
			self.adapter_latent_steps = int(self.adapter_kwargs.get("latent_steps", 1))
			self.adapter_noise_steps = int(self.adapter_kwargs.get("noise_steps", self.diffusion_act_chunk))
			self.adapter_noise_dim = int(self.adapter_kwargs.get("noise_dim", self.diffusion_act_dim))
			self.adapter_control_dim = int(self.adapter_kwargs.get("control_dim", 16))
			self.adapter_gate_dim = int(self.adapter_kwargs.get("gate_dim", 1))
			self.adapter_noise_magnitude = float(self.adapter_kwargs.get("noise_magnitude", 1.0))
			self.adapter_injection_scale = float(self.adapter_kwargs.get("injection_scale", 0.0))
			if self.adapter_latent_steps <= 0:
				raise ValueError("DSRL-NA adapter latent_steps must be positive.")
			if self.adapter_control_dim <= 0:
				raise ValueError("DSRL-NA adapter control_dim must be positive.")
			if self.adapter_gate_dim != 1:
				raise ValueError(
					f"DSRL-NA adapter gate_dim must be 1 for scalar gated injection, got {self.adapter_gate_dim}."
				)
			if self.adapter_noise_magnitude <= 0:
				raise ValueError("DSRL-NA adapter noise_magnitude must be positive.")
			if self.adapter_noise_steps != self.diffusion_act_chunk:
				raise ValueError(
					f"DSRL-NA adapter noise_steps must match diffusion chunk length: "
					f"{self.adapter_noise_steps} != {self.diffusion_act_chunk}."
				)
			if self.adapter_noise_dim != self.diffusion_act_dim:
				raise ValueError(
					f"DSRL-NA adapter noise_dim must match diffusion action dim: "
					f"{self.adapter_noise_dim} != {self.diffusion_act_dim}."
				)

			noise_size = self.adapter_noise_steps * self.adapter_noise_dim
			control_size = self.adapter_latent_steps * (self.adapter_control_dim + self.adapter_gate_dim)
			latent_low = np.concatenate([
				-np.full(noise_size, self.adapter_noise_magnitude, dtype=np.float32),
				-np.ones(control_size, dtype=np.float32),
			])
			latent_high = np.concatenate([
				np.full(noise_size, self.adapter_noise_magnitude, dtype=np.float32),
				np.ones(control_size, dtype=np.float32),
			])
			self.latent_action_space = spaces.Box(low=latent_low, high=latent_high, dtype=np.float32)

			baseline_noise_policy = self.policy_class(
				self.observation_space,
				self.action_space,
				self.lr_schedule,
				**self.policy_kwargs,
			)
			latent_policy_kwargs = dict(self.policy_kwargs)
			latent_policy_kwargs["adapter_kwargs"] = self.adapter_kwargs
			self.latent_policy = self.policy_class(
				self.observation_space,
				self.latent_action_space,
				self.lr_schedule,
				**latent_policy_kwargs,
			).to(self.device)
			self.actor = self.latent_policy.actor
			self.actor.copy_noise_parameters_from(baseline_actor)
			self.critic_noise = self.latent_policy.critic
			self._copy_noise_critic_from_baseline(baseline_noise_policy.critic, self.critic_noise)
			del baseline_noise_policy
			self._sync_adapter_runtime_scale()
		else:
			self.latent_action_space = self.action_space
			policy_noise = self.policy_class(
				self.observation_space,
				self.latent_action_space,
				self.lr_schedule,
				**self.policy_kwargs,
			)
			self.critic_noise = policy_noise.critic.to(self.device)

		# Target entropy is used when learning the entropy coefficient
		if self.target_entropy == "auto":
			if self.use_adapter_conditioning and bool(self.adapter_kwargs.get("entropy_noise_only", True)):
				self.target_entropy = float(-self.adapter_noise_steps * self.adapter_noise_dim)
			else:
				self.target_entropy = float(-np.prod(self.latent_action_space.shape).astype(np.float32))
		else:
			# Force conversion
			# this will also throw an error for unexpected string
			self.target_entropy = float(self.target_entropy)

		# The entropy coefficient or entropy can be learned automatically
		# see Automating Entropy Adjustment for Maximum Entropy RL section
		# of https://arxiv.org/abs/1812.05905
		if isinstance(self.ent_coef, str) and self.ent_coef.startswith("auto"):
			# Default initial value of ent_coef when learned
			init_value = 1.0
			if "_" in self.ent_coef:
				init_value = float(self.ent_coef.split("_")[1])
				assert init_value > 0.0, "The initial value of ent_coef must be greater than 0"

			# Note: we optimize the log of the entropy coeff which is slightly different from the paper
			# as discussed in https://github.com/rail-berkeley/softlearning/issues/37
			self.log_ent_coef = th.log(th.ones(1, device=self.device) * init_value).requires_grad_(True)
			self.ent_coef_optimizer = th.optim.Adam([self.log_ent_coef], lr=self.lr_schedule(1))
		else:
			# Force conversion to float
			# this will throw an error if a malformed string (different from 'auto')
			# is passed
			self.ent_coef_tensor = th.tensor(float(self.ent_coef), device=self.device)
		
		if isinstance(self.latent_action_space, spaces.Box):
			self.action_low_tensor = th.as_tensor(self.latent_action_space.low, device=self.device, dtype=th.float32)
			self.action_high_tensor = th.as_tensor(self.latent_action_space.high, device=self.device, dtype=th.float32)

	def _create_aliases(self) -> None:
		self.actor = self.policy.actor
		self.critic = self.policy.critic
		self.critic_target = self.policy.critic_target

	def _adapter_runtime_scale_value(self) -> float:
		if not self.use_adapter_conditioning:
			return 0.0
		if self.num_timesteps <= self.adapter_warmup_steps:
			return 0.0
		if self.adapter_ramp_steps == 0:
			return 1.0
		return float(np.clip(
			(self.num_timesteps - self.adapter_warmup_steps) / self.adapter_ramp_steps,
			0.0,
			1.0,
		))

	def _sync_adapter_runtime_scale(self) -> float:
		scale = self._adapter_runtime_scale_value()
		if self.use_adapter_conditioning:
			self.actor.set_adapter_runtime_scale(scale)
		return scale

	def _copy_noise_critic_from_baseline(
		self,
		source: ContinuousCritic,
		target: ContinuousCritic,
	) -> None:
		"""Copy the 40-D DSRL critic and zero the new adapter input columns."""
		if len(source.q_networks) != len(target.q_networks):
			raise ValueError("Baseline and adapter noise critics must use the same ensemble size.")
		noise_dim = self.adapter_noise_steps * self.adapter_noise_dim
		for source_q, target_q in zip(source.q_networks, target.q_networks):
			first_linear = True
			for source_module, target_module in zip(source_q, target_q):
				if isinstance(source_module, th.nn.Linear) and isinstance(target_module, th.nn.Linear):
					if first_linear:
						feature_dim = source_module.in_features - noise_dim
						if feature_dim <= 0:
							raise ValueError("Could not infer baseline noise critic feature dimension.")
						if source_module.in_features != feature_dim + noise_dim:
							raise ValueError("Unexpected baseline noise critic input dimension.")
						if target_module.in_features < source_module.in_features:
							raise ValueError("Adapter noise critic input cannot be smaller than baseline input.")
						adapter_columns = target_module.weight[:, feature_dim + noise_dim :].detach().clone()
						with th.no_grad():
							target_module.weight.zero_()
							target_module.weight[:, :feature_dim].copy_(source_module.weight[:, :feature_dim])
							target_module.weight[:, feature_dim : feature_dim + noise_dim].copy_(
								source_module.weight[:, feature_dim:]
							)
							target_module.weight[:, feature_dim + noise_dim :].copy_(adapter_columns)
							target_module.bias.copy_(source_module.bias)
						first_linear = False
					else:
						target_module.load_state_dict(source_module.state_dict())
				else:
					target_module.load_state_dict(source_module.state_dict())

	def _scale_action_tensor(self, action: th.Tensor) -> th.Tensor:
		assert isinstance(self.latent_action_space, spaces.Box)
		return 2.0 * ((action - self.action_low_tensor) / (self.action_high_tensor - self.action_low_tensor)) - 1.0

	def _unscale_action_tensor(self, scaled_action: th.Tensor) -> th.Tensor:
		assert isinstance(self.latent_action_space, spaces.Box)
		return self.action_low_tensor + (0.5 * (scaled_action + 1.0) * (self.action_high_tensor - self.action_low_tensor))

	def _critic_latent_action(self, scaled_latent_action: th.Tensor) -> th.Tensor:
		if self.use_adapter_conditioning:
			return self.actor.critic_adapter_action(scaled_latent_action)
		return scaled_latent_action

	def _decode_latent_action(
		self,
		obs: th.Tensor,
		latent_action: th.Tensor,
		*,
		is_scaled: bool,
	) -> th.Tensor:
		actual_latent = self._unscale_action_tensor(latent_action) if is_scaled else latent_action
		if self.use_adapter_conditioning:
			noise, adapter_feature, adapter_gate = self.actor.pack_adapter_action(actual_latent)
			diffused_action = self.diffusion_policy(
				obs,
				noise,
				return_numpy=False,
				adapter_feature=adapter_feature,
				adapter_gate=adapter_gate,
				adapter_scale=self.adapter_injection_scale,
			)
		else:
			diffused_action = self.diffusion_policy(
				obs,
				actual_latent.reshape(-1, self.diffusion_act_chunk, self.diffusion_act_dim),
				return_numpy=False,
			)
		return diffused_action.reshape(-1, self.diffusion_act_chunk * self.diffusion_act_dim)

	def _actor_action_log_prob(self, observations):
		if self.use_adapter_conditioning:
			return self.actor.action_log_prob_components(observations)
		actions, log_prob = self.actor.action_log_prob(observations)
		return actions, log_prob, th.zeros_like(log_prob)

	def train(self, gradient_steps: int, batch_size: int = 64) -> None:
		adapter_runtime_scale = self._sync_adapter_runtime_scale()
		# Switch to train mode (this affects batch norm / dropout)
		self.policy.set_training_mode(True)
		if self.use_adapter_conditioning:
			self.latent_policy.set_training_mode(True)
		self.critic_noise.set_training_mode(True)
		# Update optimizers learning rate
		optimizers = [self.actor.optimizer, self.critic.optimizer, self.critic_noise.optimizer]
		if self.ent_coef_optimizer is not None:
			optimizers += [self.ent_coef_optimizer]

		# Update learning rate according to lr schedule
		self._update_learning_rate(optimizers)

		ent_coef_losses, ent_coefs = [], []
		actor_losses, critic_losses, critic_loss_per_q_losses, noise_critic_losses = [], [], [], []
		action_l2_losses = []
		adapter_l2_losses, adapter_gate_l1_losses = [], []
		adapter_feature_norms, adapter_gate_means, adapter_effective_delta_norms = [], [], []
		adapter_noise_l2_values, adapter_control_l2_values, adapter_gate_code_l2_values = [], [], []
		adapter_noise_saturation_values = []
		adapter_control_saturation_values, adapter_gate_code_means, adapter_gate_code_saturation_values = [], [], []
		noise_log_probs, adapter_log_probs = [], []
		qf_pi_values = []

		if self.actor_gradient_steps < 0:
			actor_gradient_idx = np.arange(gradient_steps)
		elif self.actor_gradient_steps == 0:
			actor_gradient_idx = np.array([], dtype=int)
		else:
			actor_gradient_idx = np.linspace(
				int(gradient_steps / self.actor_gradient_steps) - 1,
				gradient_steps - 1,
				self.actor_gradient_steps,
				dtype=int,
			)

		# Preserve the original DSRL-NA update order: actor updates are
		# interleaved with action-critic updates, then the noise critic is fit.
		for gradient_step in range(gradient_steps):
			# Sample replay buffer
			replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)  # type: ignore[union-attr]

			# We need to sample because `log_std` may have changed between two gradient steps
			if self.use_sde:
				self.actor.reset_noise()

			# Adapter-control entropy is intentionally excluded: only diffusion
			# noise should receive the original DSRL entropy bonus.
			actions_pi, log_prob, adapter_log_prob = self._actor_action_log_prob(replay_data.observations)
			log_prob = log_prob.reshape(-1, 1)
			noise_log_probs.append(log_prob.mean().item())
			adapter_log_probs.append(adapter_log_prob.mean().item())

			ent_coef_loss = None
			if self.ent_coef_optimizer is not None and self.log_ent_coef is not None:
				# Important: detach the variable from the graph
				# so we don't change it with other losses
				# see https://github.com/rail-berkeley/softlearning/issues/60
				ent_coef = th.exp(self.log_ent_coef.detach())
				ent_coef_loss = -(self.log_ent_coef * (log_prob + self.target_entropy).detach()).mean()
				ent_coef_losses.append(ent_coef_loss.item())
			else:
				ent_coef = self.ent_coef_tensor

			ent_coefs.append(ent_coef.item())

			# Optimize entropy coefficient, also called
			# entropy temperature or alpha in the paper
			if ent_coef_loss is not None and self.ent_coef_optimizer is not None:
				self.ent_coef_optimizer.zero_grad()
				ent_coef_loss.backward()
				self.ent_coef_optimizer.step()

			with th.no_grad():
				# Select action according to policy
				next_latent_actions, next_log_prob, _ = self._actor_action_log_prob(replay_data.next_observations)
				next_actions = self._decode_latent_action(
					replay_data.next_observations,
					next_latent_actions,
					is_scaled=True,
				)
				# Compute the next Q values: min over all critics targets
				next_q_values = th.cat(self.critic_target(replay_data.next_observations, next_actions), dim=1)
				if self.critic_backup_combine_type == 'min':
					next_q_values, _ = th.min(next_q_values, dim=1, keepdim=True)
				elif self.critic_backup_combine_type == 'mean':
					next_q_values = th.mean(next_q_values, dim=1, keepdim=True)
				# add entropy term
				next_q_values = next_q_values - ent_coef * next_log_prob.reshape(-1, 1)
				# td error + entropy term
				target_q_values = replay_data.rewards + (1 - replay_data.dones) * self.gamma * next_q_values

			# Get current Q-values estimates for each critic network
			# using action from the replay buffer
			current_q_values = self.critic(replay_data.observations, replay_data.actions)

			# Compute critic loss
			critic_loss = 0.5 * sum(F.mse_loss(current_q, target_q_values) for current_q in current_q_values)
			assert isinstance(critic_loss, th.Tensor)  # for type checker
			critic_losses.append(critic_loss.item())  # type: ignore[union-attr]
			critic_loss_per_q_losses.append(critic_loss.item() / max(len(current_q_values), 1))

			# Optimize the critic
			self.critic.optimizer.zero_grad()
			critic_loss.backward()
			self.critic.optimizer.step()

			if gradient_step in actor_gradient_idx:
				critic_latent_actions = self._critic_latent_action(actions_pi)
				for parameter in self.critic_noise.parameters():
					parameter.requires_grad_(False)
				q_values_pi = th.cat(
					self.critic_noise(replay_data.observations, critic_latent_actions),
					dim=1,
				)
				if self.critic_backup_combine_type == 'min':
					min_qf_pi, _ = th.min(q_values_pi, dim=1, keepdim=True)
				elif self.critic_backup_combine_type == 'mean':
					min_qf_pi = th.mean(q_values_pi, dim=1, keepdim=True)
				else:
					raise ValueError(f"Unknown critic backup combine type: {self.critic_backup_combine_type}")
				qf_pi_values.append(min_qf_pi.mean().item())
				action_l2 = th.mean(actions_pi.pow(2))
				action_l2_losses.append(action_l2.item())
				actor_loss = (ent_coef * log_prob - min_qf_pi).mean()
				if self.action_norm_regularization > 0:
					actor_loss = actor_loss + 0.5 * self.action_norm_regularization * action_l2
				if self.use_adapter_conditioning:
					noise_code, control_code, gate_code = self.actor._split_adapter_action(actions_pi)
					control_code_l2 = th.mean(control_code.pow(2))
					gate_code_l2 = th.mean(gate_code.pow(2))
					adapter_noise_l2_values.append(th.mean(noise_code.pow(2)).item())
					adapter_control_l2_values.append(control_code_l2.item())
					adapter_gate_code_l2_values.append(gate_code_l2.item())
					adapter_noise_saturation_values.append(th.mean((noise_code.abs() > 0.95).float()).item())
					adapter_control_saturation_values.append(th.mean((control_code.abs() > 0.95).float()).item())
					adapter_gate_code_means.append(gate_code.mean().item())
					adapter_gate_code_saturation_values.append(th.mean((gate_code.abs() > 0.95).float()).item())
					adapter_l2, gate_l1, feature_norm, gate_mean, effective_delta_norm = self.actor.adapter_regularization(actions_pi)
					actor_loss = (
						actor_loss
						+ self.adapter_l2_coef * adapter_l2
						+ self.adapter_gate_l1_coef * gate_l1
						+ self.adapter_control_l2_coef * control_code_l2
						+ self.adapter_gate_code_l2_coef * gate_code_l2
					)
					adapter_l2_losses.append(adapter_l2.item())
					adapter_gate_l1_losses.append(gate_l1.item())
					adapter_feature_norms.append(feature_norm.item())
					adapter_gate_means.append(gate_mean.item())
					adapter_effective_delta_norms.append(effective_delta_norm.item())
				actor_losses.append(actor_loss.item())

				self.actor.optimizer.zero_grad()
				actor_loss.backward()
				if self.use_adapter_conditioning:
					# Runtime gating already scales the Q gradient through the
					# physical adapter path. Applying it again here suppresses the
					# adapter quadratically during ramp-up.
					self.actor.scale_adapter_gradients(self.adapter_gradient_scale)
				self.actor.optimizer.step()
				for parameter in self.critic_noise.parameters():
					parameter.requires_grad_(True)

			# Update target networks
			if gradient_step % self.target_update_interval == 0:
				polyak_update(self.critic.parameters(), self.critic_target.parameters(), self.tau)
				# Copy running stats, see GH issue #996
				polyak_update(self.batch_norm_stats, self.batch_norm_stats_target, 1.0)

		for gradient_step in range(self.noise_critic_grad_steps):
			# Sample replay buffer
			critic_distill_loss = 0
			replay_data = self.replay_buffer.sample(batch_size, env=self._vec_normalize_env)  # type: ignore[union-attr]
			critic_distill_loss = critic_distill_loss + self.update_noise_critic(replay_data)
			noise_critic_losses.append(critic_distill_loss.item())
			self.critic_noise.optimizer.zero_grad()
			critic_distill_loss.backward()
			self.critic_noise.optimizer.step()

		self.critic_noise.set_training_mode(False)
		if self.use_adapter_conditioning:
			self.latent_policy.set_training_mode(False)
		self._n_updates += gradient_steps

		self.logger.record("train/n_updates", self._n_updates, exclude="tensorboard")
		self.logger.record("train/ent_coef", np.mean(ent_coefs))
		if len(actor_losses) > 0:
			self.logger.record("train/actor_loss", np.mean(actor_losses))
		self.logger.record("train/critic_loss", np.mean(critic_losses))
		self.logger.record("train/critic_loss_per_q", np.mean(critic_loss_per_q_losses))
		if len(noise_critic_losses) > 0:
			self.logger.record("train/noise_critic_loss", np.mean(noise_critic_losses))
		self.logger.record("train/noise_log_prob", np.mean(noise_log_probs))
		self.logger.record("train/adapter_log_prob", np.mean(adapter_log_probs))
		if len(action_l2_losses) > 0:
			self.logger.record("train/action_l2", np.mean(action_l2_losses))
			self.logger.record("train/qf_pi", np.mean(qf_pi_values))
		if len(adapter_l2_losses) > 0:
			self.logger.record("train/adapter_l2", np.mean(adapter_l2_losses))
			self.logger.record("train/adapter_gate_l1", np.mean(adapter_gate_l1_losses))
			self.logger.record("train/adapter_feature_norm", np.mean(adapter_feature_norms))
			self.logger.record("train/adapter_gate_mean", np.mean(adapter_gate_means))
			self.logger.record("train/adapter_effective_delta_norm", np.mean(adapter_effective_delta_norms))
			self.logger.record("train/noise_l2", np.mean(adapter_noise_l2_values))
			self.logger.record("train/control_code_l2", np.mean(adapter_control_l2_values))
			self.logger.record("train/gate_code_l2", np.mean(adapter_gate_code_l2_values))
			self.logger.record("train/noise_saturation_rate", np.mean(adapter_noise_saturation_values))
			self.logger.record("train/control_code_saturation_rate", np.mean(adapter_control_saturation_values))
			self.logger.record("train/gate_code_mean", np.mean(adapter_gate_code_means))
			self.logger.record("train/gate_code_saturation_rate", np.mean(adapter_gate_code_saturation_values))
			self.logger.record("train/adapter_runtime_scale", adapter_runtime_scale)
		if len(ent_coef_losses) > 0:
			self.logger.record("train/ent_coef_loss", np.mean(ent_coef_losses))


	def update_noise_critic(self, replay_data):
		with th.no_grad():
			if self.use_adapter_conditioning:
				latent_actions, _ = self.actor.action_log_prob(replay_data.observations)
				noise_actions = th.randn(
					replay_data.actions.shape[0],
					self.diffusion_act_chunk,
					self.diffusion_act_dim,
					device=self.device,
				).reshape(replay_data.actions.shape[0], -1)
				noise_size = self.adapter_noise_steps * self.adapter_noise_dim
				noise_low = self.action_low_tensor[:noise_size]
				noise_high = self.action_high_tensor[:noise_size]
				scaled_noise = 2.0 * ((noise_actions - noise_low) / (noise_high - noise_low)) - 1.0
				latent_actions = latent_actions.clone()
				latent_actions[:, :noise_size] = scaled_noise
				diffused_actions = self._decode_latent_action(
					replay_data.observations,
					latent_actions,
					is_scaled=True,
				)
				critic_latent_actions = self._critic_latent_action(latent_actions).detach()
			else:
				noise_actions = th.randn(
					replay_data.actions.shape[0],
					self.diffusion_act_chunk,
					self.diffusion_act_dim,
					device=self.device,
				)
				diffused_actions = self.diffusion_policy(
					replay_data.observations,
					noise_actions,
					return_numpy=False,
				)
				diffused_actions = diffused_actions.reshape(-1, self.diffusion_act_chunk * self.diffusion_act_dim)
				noise_actions = noise_actions.reshape(-1, self.diffusion_act_chunk * self.diffusion_act_dim).detach()
				critic_latent_actions = self._scale_action_tensor(noise_actions)
			current_q_values = self.critic(replay_data.observations, diffused_actions)
		current_q_noise_vals = self.critic_noise(replay_data.observations, critic_latent_actions)
		critic_distill_loss = 0
		for i in range(len(current_q_values)):
			current_q = current_q_values[i]
			current_q_noise = current_q_noise_vals[i]
			critic_distill_loss = critic_distill_loss + 0.5*F.mse_loss(current_q.detach(), current_q_noise)
		return critic_distill_loss


	def learn(
		self: SelfDSRL,
		total_timesteps: int,
		callback: MaybeCallback = None,
		log_interval: int = 4,
		tb_log_name: str = "SAC",
		reset_num_timesteps: bool = True,
		progress_bar: bool = False,
	) -> SelfDSRL:
		return super().learn(
			total_timesteps=total_timesteps,
			callback=callback,
			log_interval=log_interval,
			tb_log_name=tb_log_name,
			reset_num_timesteps=reset_num_timesteps,
			progress_bar=progress_bar,
		)

	def _excluded_save_params(self) -> list[str]:
		return super()._excluded_save_params() + ["actor", "critic", "critic_target"]  # noqa: RUF005

	def _get_torch_save_params(self) -> tuple[list[str], list[str]]:
		if self.use_adapter_conditioning:
			state_dicts = [
				"policy",
				"latent_policy",
				"actor.optimizer",
				"critic.optimizer",
				"critic_noise.optimizer",
			]
		else:
			state_dicts = [
				"policy",
				"actor.optimizer",
				"critic.optimizer",
				"critic_noise",
				"critic_noise.optimizer",
			]
		if self.ent_coef_optimizer is not None:
			saved_pytorch_variables = ["log_ent_coef"]
			state_dicts.append("ent_coef_optimizer")
		else:
			saved_pytorch_variables = ["ent_coef_tensor"]
		# import pdb; pdb.set_trace()
		return state_dicts, saved_pytorch_variables
	
	def _sample_action(
		self,
		learning_starts: int,
		action_noise: Optional[ActionNoise] = None,
		n_envs: int = 1,
	) -> tuple[np.ndarray, np.ndarray]:
		"""
		Sample an action according to the exploration policy.
		This is either done by sampling the probability distribution of the policy,
		or sampling a random action (from a uniform distribution over the action space)
		or by adding noise to the deterministic output.

		:param action_noise: Action noise that will be used for exploration
			Required for deterministic policy (e.g. TD3). This can also be used
			in addition to the stochastic policy for SAC.
		:param learning_starts: Number of steps before learning for the warm-up phase.
		:param n_envs:
		:return: action to take in the environment
			and scaled action that will be stored in the replay buffer.
			The two differs when the action space is not normalized (bounds are not [-1, 1]).
		"""
		if self.use_adapter_conditioning:
			self._sync_adapter_runtime_scale()
			if self.num_timesteps < learning_starts and not (self.use_sde and self.use_sde_at_warmup):
				latent_action = np.array([self.latent_action_space.sample() for _ in range(n_envs)])
			else:
				assert self._last_obs is not None, "self._last_obs was not set"
				latent_action, _ = self.actor.predict(self._last_obs, deterministic=False)

			if action_noise is not None:
				scaled_latent = 2.0 * (
					(latent_action - self.latent_action_space.low)
					/ (self.latent_action_space.high - self.latent_action_space.low)
				) - 1.0
				scaled_latent = np.clip(scaled_latent + action_noise(), -1.0, 1.0)
				latent_action = self.latent_action_space.low + 0.5 * (
					(scaled_latent + 1.0)
					* (self.latent_action_space.high - self.latent_action_space.low)
				)

			latent_tensor = th.as_tensor(latent_action, device=self.device, dtype=th.float32)
			obs_tensor = th.as_tensor(self._last_obs, device=self.device, dtype=th.float32)
			with th.no_grad():
				action_tensor = self._decode_latent_action(
					obs_tensor,
					latent_tensor,
					is_scaled=False,
				)
			action = action_tensor.cpu().numpy()
			return action, action

		# Select action randomly or according to policy
		if self.num_timesteps < learning_starts and not (self.use_sde and self.use_sde_at_warmup):
			# Warmup phase
			unscaled_action = np.array([self.action_space.sample() for _ in range(n_envs)])
		else:
			# Note: when using continuous actions,
			# we assume that the policy uses tanh to scale the action
			# We use non-deterministic action in the case of SAC, for TD3, it does not matter
			assert self._last_obs is not None, "self._last_obs was not set"
			unscaled_action, _ = self.predict(self._last_obs, deterministic=False)

		# Rescale the action from [low, high] to [-1, 1]
		if isinstance(self.action_space, spaces.Box):
			scaled_action = self.policy.scale_action(unscaled_action)

			# Add noise to the action (improve exploration)
			if action_noise is not None:
				scaled_action = np.clip(scaled_action + action_noise(), -1, 1)

			# We store the scaled action in the buffer
			buffer_action = scaled_action
			action = self.policy.unscale_action(scaled_action)
		else:
			# Discrete case, no need to normalize or clip
			buffer_action = unscaled_action
			action = buffer_action
		action = th.as_tensor(action, device=self.device, dtype=th.float32)
		obs = th.as_tensor(self._last_obs, device=self.device, dtype=th.float32)
		action = self.diffusion_policy(obs, action.reshape(-1, self.diffusion_act_chunk, self.diffusion_act_dim), return_numpy=False)
		action = action.reshape(-1, self.diffusion_act_chunk * self.diffusion_act_dim)
		action = action.cpu().numpy()
		buffer_action = action
		return action, buffer_action

	def predict_diffused(
		self,
		observation: Union[np.ndarray, dict[str, np.ndarray]],
		state: Optional[tuple[np.ndarray, ...]] = None,
		episode_start: Optional[np.ndarray] = None,
		deterministic: bool = False,
	) -> tuple[np.ndarray, Optional[tuple[np.ndarray, ...]]]:
		if self.use_adapter_conditioning:
			self._sync_adapter_runtime_scale()
			latent_action, predict_second_return = self.actor.predict(
				observation,
				state,
				episode_start,
				deterministic,
			)
			latent_tensor = th.as_tensor(latent_action, device=self.device, dtype=th.float32)
			obs_tensor = th.as_tensor(observation, device=self.device, dtype=th.float32)
			with th.no_grad():
				action_tensor = self._decode_latent_action(
					obs_tensor,
					latent_tensor,
					is_scaled=False,
				)
			return action_tensor.cpu().numpy(), predict_second_return

		unscaled_action, predict_second_return = self.policy.predict(observation, state, episode_start, deterministic)
		if isinstance(self.action_space, spaces.Box):
			scaled_action = self.policy.scale_action(unscaled_action)
			# We store the scaled action in the buffer
			buffer_action = scaled_action
			action = self.policy.unscale_action(scaled_action)
		else:
			# Discrete case, no need to normalize or clip
			buffer_action = unscaled_action
			action = buffer_action
		action = th.as_tensor(action, device=self.device, dtype=th.float32)
		obs = th.as_tensor(observation, device=self.device, dtype=th.float32)
		action = self.diffusion_policy(obs, action.reshape(-1, self.diffusion_act_chunk, self.diffusion_act_dim), return_numpy=False)
		action = action.reshape(-1, self.diffusion_act_chunk * self.diffusion_act_dim)
		action = action.cpu().numpy()
		return action, predict_second_return

	def adapter_action_diagnostics(
		self,
		observation: Union[np.ndarray, dict[str, np.ndarray]],
		deterministic: bool = False,
	) -> Optional[dict[str, float]]:
		"""Measure the final-action change caused by adapter injection for fixed noise."""
		if not self.use_adapter_conditioning:
			return None
		runtime_scale = self._sync_adapter_runtime_scale()
		latent_action, _ = self.actor.predict(observation, deterministic=deterministic)
		latent_tensor = th.as_tensor(latent_action, device=self.device, dtype=th.float32)
		obs_tensor = th.as_tensor(observation, device=self.device, dtype=th.float32)
		with th.no_grad():
			action_with = self._decode_latent_action(obs_tensor, latent_tensor, is_scaled=False)
			self.actor.set_adapter_runtime_scale(0.0)
			try:
				action_without = self._decode_latent_action(obs_tensor, latent_tensor, is_scaled=False)
			finally:
				self.actor.set_adapter_runtime_scale(runtime_scale)
		diff = th.linalg.vector_norm(action_with - action_without, dim=-1)
		action_norm = th.linalg.vector_norm(action_with, dim=-1).clamp_min(1e-8)
		ratio = diff / action_norm
		return {
			"adapter_action_diff_norm": diff.mean().item(),
			"adapter_action_diff_ratio": ratio.mean().item(),
			"adapter_action_diff_ratio_max": ratio.max().item(),
		}
