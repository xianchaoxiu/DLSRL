from typing import Any, Optional, Union

import numpy as np
import torch as th
from gymnasium import spaces
from torch import nn

from stable_baselines3.common.distributions import SquashedDiagGaussianDistribution, DiagGaussianDistribution, StateDependentNoiseDistribution
from stable_baselines3.common.policies import BasePolicy, ContinuousCritic
from stable_baselines3.common.preprocessing import get_action_dim
from stable_baselines3.common.torch_layers import (
    BaseFeaturesExtractor,
    CombinedExtractor,
    FlattenExtractor,
    NatureCNN,
    create_mlp,
    get_actor_critic_arch,
)
from stable_baselines3.common.type_aliases import PyTorchObs, Schedule

# CAP the standard deviation of the actor
LOG_STD_MAX = 2
LOG_STD_MIN = -20


class Actor(BasePolicy):
    """
    Actor network (policy) for SAC.

    :param observation_space: Observation space
    :param action_space: Action space
    :param net_arch: Network architecture
    :param features_extractor: Network to extract features
        (a CNN when using images, a nn.Flatten() layer otherwise)
    :param features_dim: Number of features
    :param activation_fn: Activation function
    :param use_sde: Whether to use State Dependent Exploration or not
    :param log_std_init: Initial value for the log standard deviation
    :param full_std: Whether to use (n_features x n_actions) parameters
        for the std instead of only (n_features,) when using gSDE.
    :param use_expln: Use ``expln()`` function instead of ``exp()`` when using gSDE to ensure
        a positive standard deviation (cf paper). It allows to keep variance
        above zero and prevent it from growing too fast. In practice, ``exp()`` is usually enough.
    :param clip_mean: Clip the mean output when using gSDE to avoid numerical instability.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    """

    action_space: spaces.Box

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        net_arch: list[int],
        features_extractor: nn.Module,
        features_dim: int,
        activation_fn: type[nn.Module] = nn.ReLU,
        use_sde: bool = False,
        log_std_init: float = -3,
        full_std: bool = True,
        use_expln: bool = False,
        clip_mean: float = 2.0,
        normalize_images: bool = True,
        post_linear_modules: Optional[list[type[nn.Module]]] = None,
        standard_gauss_init: bool = False,
        adapter_kwargs: Optional[dict[str, Any]] = None,
    ):
        super().__init__(
            observation_space,
            action_space,
            features_extractor=features_extractor,
            normalize_images=normalize_images,
            squash_output=True,
        )

        # Save arguments to re-create object at loading
        self.use_sde = use_sde
        self.sde_features_extractor = None
        self.net_arch = net_arch
        self.features_dim = features_dim
        self.activation_fn = activation_fn
        self.log_std_init = log_std_init
        self.use_expln = use_expln
        self.full_std = full_std
        self.clip_mean = clip_mean
        self.standard_gauss_init = standard_gauss_init
        self.adapter_kwargs = adapter_kwargs or {}
        self.use_adapter_conditioning = bool(self.adapter_kwargs.get("enabled", False))

        action_dim = get_action_dim(self.action_space)
        latent_pi_net = create_mlp(features_dim, -1, net_arch, activation_fn, post_linear_modules=post_linear_modules)
        self.latent_pi = nn.Sequential(*latent_pi_net)
        last_layer_dim = net_arch[-1] if len(net_arch) > 0 else features_dim

        if self.use_sde:
            self.action_dist = StateDependentNoiseDistribution(
                action_dim, full_std=full_std, use_expln=use_expln, learn_features=True, squash_output=True
            )
            self.mu, self.log_std = self.action_dist.proba_distribution_net(
                latent_dim=last_layer_dim, latent_sde_dim=last_layer_dim, log_std_init=log_std_init
            )
            # Avoid numerical issues by limiting the mean of the Gaussian
            # to be in [-clip_mean, clip_mean]
            if clip_mean > 0.0:
                self.mu = nn.Sequential(self.mu, nn.Hardtanh(min_val=-clip_mean, max_val=clip_mean))
        else:
            if standard_gauss_init:
                self.action_dist = SquashedDiagGaussianDistribution(action_dim)  # type: ignore[assignment]
                self.mu = nn.Linear(last_layer_dim, action_dim)
                nn.init.zeros_(self.mu.weight)
                nn.init.zeros_(self.mu.bias)
                self.log_std = nn.Linear(last_layer_dim, action_dim)  # type: ignore[assignment]
                nn.init.zeros_(self.log_std.weight)
                nn.init.zeros_(self.log_std.bias)
            else:
                self.action_dist = SquashedDiagGaussianDistribution(action_dim)  # type: ignore[assignment]
                self.mu = nn.Linear(last_layer_dim, action_dim)
                self.log_std = nn.Linear(last_layer_dim, action_dim)  # type: ignore[assignment]

        if self.use_adapter_conditioning:
            self.adapter_latent_steps = int(self.adapter_kwargs.get("latent_steps", 1))
            self.adapter_noise_steps = int(self.adapter_kwargs.get("noise_steps", self.adapter_latent_steps))
            self.adapter_noise_dim = int(self.adapter_kwargs["noise_dim"])
            self.adapter_control_dim = int(self.adapter_kwargs.get("control_dim", 16))
            self.adapter_gate_dim = int(self.adapter_kwargs.get("gate_dim", 1))
            self.adapter_feature_dim = int(self.adapter_kwargs["feature_dim"])
            self.adapter_hidden_dim = int(self.adapter_kwargs.get("hidden_dim", 128))
            self.adapter_feature_init_std = float(self.adapter_kwargs.get("feature_init_std", 1e-3))
            self.adapter_feature_scale = float(self.adapter_kwargs.get("feature_scale", 0.25))
            self.adapter_gate_max = float(self.adapter_kwargs.get("gate_max", 0.2))
            self.adapter_gate_logit_scale = float(self.adapter_kwargs.get("gate_logit_scale", 5.0))
            self.adapter_gate_logit_bias = float(self.adapter_kwargs.get("gate_logit_bias", -2.5))
            self.adapter_injection_scale = float(self.adapter_kwargs.get("injection_scale", 1.0))
            self.adapter_critic_effect_scale = float(self.adapter_kwargs.get("critic_effect_scale", 1.0))
            self.adapter_control_log_std_init = float(self.adapter_kwargs.get("control_log_std_init", -3.0))
            self.adapter_entropy_noise_only = bool(self.adapter_kwargs.get("entropy_noise_only", True))
            self.adapter_runtime_scale = 1.0
            self.adapter_control_action_dim = self.adapter_control_dim + self.adapter_gate_dim
            self.adapter_noise_size = self.adapter_noise_steps * self.adapter_noise_dim
            expected_action_dim = self.adapter_noise_size + self.adapter_latent_steps * self.adapter_control_action_dim
            if action_dim != expected_action_dim:
                raise ValueError(
                    f"Adapter action dim mismatch: action_space has {action_dim}, "
                    f"but noise_steps * noise_dim + latent_steps * (control_dim + gate_dim) = "
                    f"{self.adapter_noise_steps} * {self.adapter_noise_dim} + "
                    f"{self.adapter_latent_steps} * {self.adapter_control_action_dim} = {expected_action_dim}."
                )
            if self.adapter_feature_dim % self.adapter_control_dim != 0:
                raise ValueError(
                    f"adapter feature_dim {self.adapter_feature_dim} must be divisible by "
                    f"control_dim {self.adapter_control_dim}."
                )
            if self.adapter_feature_scale <= 0:
                raise ValueError("adapter feature_scale must be positive.")
            if self.adapter_gate_max <= 0:
                raise ValueError("adapter gate_max must be positive.")
            if self.adapter_feature_init_std < 0:
                raise ValueError("adapter feature_init_std must be non-negative.")
            if self.adapter_critic_effect_scale <= 0:
                raise ValueError("adapter critic_effect_scale must be positive.")
            self.adapter_fc1 = nn.Linear(self.adapter_control_dim, self.adapter_hidden_dim)
            self.adapter_fc2 = nn.Linear(self.adapter_hidden_dim, self.adapter_feature_dim)
            # Runtime gating keeps warmup behavior identical to DSRL-NA. A
            # tiny non-zero head is still required so Q gradients can reach
            # the adapter once the ramp starts.
            nn.init.normal_(self.adapter_fc2.weight, mean=0.0, std=self.adapter_feature_init_std)
            nn.init.zeros_(self.adapter_fc2.bias)

            # Preserve the baseline initialization for the diffusion-noise rows.
            # Adapter controls start near zero with low exploration variance.
            with th.no_grad():
                self.mu.weight[self.adapter_noise_size :].zero_()
                self.mu.bias[self.adapter_noise_size :].zero_()
                self.log_std.weight[self.adapter_noise_size :].zero_()
                self.log_std.bias[self.adapter_noise_size :].fill_(self.adapter_control_log_std_init)

    def set_adapter_runtime_scale(self, scale: float) -> None:
        if not self.use_adapter_conditioning:
            return
        self.adapter_runtime_scale = float(np.clip(scale, 0.0, 1.0))

    def copy_noise_parameters_from(self, source: "Actor") -> None:
        """Start the adapter actor from the same learned-noise policy as DSRL-NA."""
        if not self.use_adapter_conditioning:
            raise RuntimeError("copy_noise_parameters_from() requires adapter conditioning.")
        if not all(isinstance(layer, nn.Linear) for layer in (self.mu, self.log_std, source.mu, source.log_std)):
            raise TypeError("Noise parameter copying currently requires non-gSDE linear output heads.")
        if source.mu.out_features != self.adapter_noise_size:
            raise ValueError(
                f"Baseline actor has {source.mu.out_features} actions, expected {self.adapter_noise_size} noise actions."
            )
        self.latent_pi.load_state_dict(source.latent_pi.state_dict())
        with th.no_grad():
            self.mu.weight[: self.adapter_noise_size].copy_(source.mu.weight)
            self.mu.bias[: self.adapter_noise_size].copy_(source.mu.bias)
            self.log_std.weight[: self.adapter_noise_size].copy_(source.log_std.weight)
            self.log_std.bias[: self.adapter_noise_size].copy_(source.log_std.bias)

    def scale_adapter_gradients(self, scale: float) -> None:
        """Reduce adapter-only gradients without changing the DSRL noise learning rate."""
        if not self.use_adapter_conditioning:
            return
        scale = float(scale)
        for module in (self.adapter_fc1, self.adapter_fc2):
            for parameter in module.parameters():
                if parameter.grad is not None:
                    parameter.grad.mul_(scale)
        for layer in (self.mu, self.log_std):
            if not isinstance(layer, nn.Linear):
                raise TypeError("Adapter gradient scaling currently requires non-gSDE linear output heads.")
            if layer.weight.grad is not None:
                layer.weight.grad[self.adapter_noise_size :].mul_(scale)
            if layer.bias.grad is not None:
                layer.bias.grad[self.adapter_noise_size :].mul_(scale)

    def _get_constructor_parameters(self) -> dict[str, Any]:
        data = super()._get_constructor_parameters()

        data.update(
            dict(
                net_arch=self.net_arch,
                features_dim=self.features_dim,
                activation_fn=self.activation_fn,
                use_sde=self.use_sde,
                log_std_init=self.log_std_init,
                full_std=self.full_std,
                use_expln=self.use_expln,
                features_extractor=self.features_extractor,
                clip_mean=self.clip_mean,
                adapter_kwargs=self.adapter_kwargs,
            )
        )
        return data

    def _reshape_adapter_action(self, action: th.Tensor) -> th.Tensor:
        if action.ndim == 3:
            return action.reshape(action.shape[0], -1)
        if action.ndim != 2:
            raise ValueError(f"Expected adapter action with 2 or 3 dims, got {tuple(action.shape)}")
        return action

    def _split_adapter_action(self, action: th.Tensor) -> tuple[th.Tensor, th.Tensor, th.Tensor]:
        action = self._reshape_adapter_action(action)
        noise_end = self.adapter_noise_steps * self.adapter_noise_dim
        control_end = noise_end + self.adapter_latent_steps * self.adapter_control_dim
        gate_end = control_end + self.adapter_latent_steps * self.adapter_gate_dim
        noise = action[..., :noise_end].reshape(action.shape[0], self.adapter_noise_steps, self.adapter_noise_dim)
        control_code = action[..., noise_end:control_end].reshape(
            action.shape[0],
            self.adapter_latent_steps,
            self.adapter_control_dim,
        )
        gate_code = action[..., control_end:gate_end].reshape(
            action.shape[0],
            self.adapter_latent_steps,
            self.adapter_gate_dim,
        )
        return noise, control_code, gate_code

    def _adapter_feature_from_control(self, control_code: th.Tensor) -> th.Tensor:
        feature = self.adapter_fc1(control_code)
        feature = th.relu(feature)
        feature = self.adapter_fc2(feature)
        return self.adapter_feature_scale * th.tanh(feature)

    def adapter_gate_from_code(self, gate_code: th.Tensor) -> th.Tensor:
        gate_logits = self.adapter_gate_logit_scale * gate_code + self.adapter_gate_logit_bias
        return self.adapter_gate_max * th.sigmoid(gate_logits)

    def pack_adapter_action(self, action: th.Tensor) -> tuple[th.Tensor, th.Tensor, th.Tensor]:
        """Map low-dim latent action to diffusion noise plus hidden adapter controls."""
        if not self.use_adapter_conditioning:
            raise RuntimeError("pack_adapter_action() requires adapter conditioning to be enabled.")
        noise, control_code, gate_code = self._split_adapter_action(action)
        adapter_feature = self._adapter_feature_from_control(control_code)
        adapter_gate = self.adapter_runtime_scale * self.adapter_gate_from_code(gate_code)
        return noise, adapter_feature, adapter_gate

    def critic_adapter_action(self, action: th.Tensor) -> th.Tensor:
        """Low-dimensional critic action aligned with the effective hidden-state modulation."""
        if not self.use_adapter_conditioning:
            return action
        noise, adapter_feature, adapter_gate = self.pack_adapter_action(action)
        # Preserve the direction and strength of the physical residual while
        # presenting it to the critic at a numerically useful feature scale.
        effective_feature = self.adapter_injection_scale * adapter_gate * th.tanh(adapter_feature)
        critic_feature = self.adapter_critic_effect_scale * effective_feature
        group_size = self.adapter_feature_dim // self.adapter_control_dim
        adapter_summary = critic_feature.reshape(
            *critic_feature.shape[:-1],
            self.adapter_control_dim,
            group_size,
        ).mean(dim=-1)
        adapter_strength = (
            th.linalg.vector_norm(critic_feature, dim=-1, keepdim=True)
            / (self.adapter_feature_dim ** 0.5)
        )
        return th.cat(
            [
                noise.reshape(action.shape[0], -1),
                adapter_summary.reshape(action.shape[0], -1),
                adapter_strength.reshape(action.shape[0], -1),
            ],
            dim=-1,
        )

    def adapter_regularization(self, action: th.Tensor) -> tuple[th.Tensor, th.Tensor, th.Tensor, th.Tensor, th.Tensor]:
        if not self.use_adapter_conditioning:
            zero = th.zeros((), device=action.device)
            return zero, zero, zero, zero, zero
        _, control_code, gate_code = self._split_adapter_action(action)
        adapter_feature = self._adapter_feature_from_control(control_code)
        raw_adapter_gate = self.adapter_gate_from_code(gate_code)
        adapter_gate = self.adapter_runtime_scale * raw_adapter_gate
        adapter_l2 = th.mean(adapter_feature.pow(2))
        # Penalize the requested gate before runtime ramping so the constraint
        # does not disappear during warmup and become active after saturation.
        gate_l1 = th.mean(raw_adapter_gate.abs())
        feature_norm = th.linalg.norm(adapter_feature, dim=-1).mean()
        gate_mean = adapter_gate.mean()
        effective_delta = self.adapter_injection_scale * adapter_gate * th.tanh(adapter_feature)
        effective_delta_norm = th.linalg.norm(effective_delta, dim=-1).mean()
        return adapter_l2, gate_l1, feature_norm, gate_mean, effective_delta_norm

    def action_log_prob_components(self, obs: PyTorchObs) -> tuple[th.Tensor, th.Tensor, th.Tensor]:
        """Sample an action and split entropy into noise and adapter-control components."""
        actions, full_log_prob = self.action_log_prob(obs)
        if not self.use_adapter_conditioning or not self.adapter_entropy_noise_only:
            return actions, full_log_prob, th.zeros_like(full_log_prob)
        if not isinstance(self.action_dist, SquashedDiagGaussianDistribution):
            raise RuntimeError("Adapter entropy splitting requires a squashed diagonal Gaussian actor.")
        gaussian_actions = self.action_dist.gaussian_actions
        distribution = self.action_dist.distribution
        if gaussian_actions is None or distribution is None:
            raise RuntimeError("Action distribution was not sampled before entropy splitting.")
        per_dim_log_prob = distribution.log_prob(gaussian_actions)
        per_dim_log_prob -= th.log(1 - actions.pow(2) + self.action_dist.epsilon)
        noise_log_prob = per_dim_log_prob[:, : self.adapter_noise_size].sum(dim=1)
        adapter_log_prob = per_dim_log_prob[:, self.adapter_noise_size :].sum(dim=1)
        return actions, noise_log_prob, adapter_log_prob

    def get_std(self) -> th.Tensor:
        """
        Retrieve the standard deviation of the action distribution.
        Only useful when using gSDE.
        It corresponds to ``th.exp(log_std)`` in the normal case,
        but is slightly different when using ``expln`` function
        (cf StateDependentNoiseDistribution doc).

        :return:
        """
        msg = "get_std() is only available when using gSDE"
        assert isinstance(self.action_dist, StateDependentNoiseDistribution), msg
        return self.action_dist.get_std(self.log_std)

    def reset_noise(self, batch_size: int = 1) -> None:
        """
        Sample new weights for the exploration matrix, when using gSDE.

        :param batch_size:
        """
        msg = "reset_noise() is only available when using gSDE"
        assert isinstance(self.action_dist, StateDependentNoiseDistribution), msg
        self.action_dist.sample_weights(self.log_std, batch_size=batch_size)

    def get_action_dist_params(self, obs: PyTorchObs) -> tuple[th.Tensor, th.Tensor, dict[str, th.Tensor]]:
        """
        Get the parameters for the action distribution.

        :param obs:
        :return:
            Mean, standard deviation and optional keyword arguments.
        """
        features = self.extract_features(obs, self.features_extractor)
        latent_pi = self.latent_pi(features)
        mean_actions = self.mu(latent_pi)

        if self.use_sde:
            return mean_actions, self.log_std, dict(latent_sde=latent_pi)
        # Unstructured exploration (Original implementation)
        log_std = self.log_std(latent_pi)  # type: ignore[operator]
        # Original Implementation to cap the standard deviation
        if not self.standard_gauss_init:
            log_std = th.clamp(log_std, LOG_STD_MIN, LOG_STD_MAX)
        return mean_actions, log_std, {}

    def forward(self, obs: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        mean_actions, log_std, kwargs = self.get_action_dist_params(obs)
        # Note: the action is squashed
        return self.action_dist.actions_from_params(mean_actions, log_std, deterministic=deterministic, **kwargs)

    def action_log_prob(self, obs: PyTorchObs) -> tuple[th.Tensor, th.Tensor]:
        mean_actions, log_std, kwargs = self.get_action_dist_params(obs)
        # return action and associated log prob
        return self.action_dist.log_prob_from_params(mean_actions, log_std, **kwargs)

    def _predict(self, observation: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        return self(observation, deterministic)


class SACPolicy(BasePolicy):
    """
    Policy class (with both actor and critic) for SAC.

    :param observation_space: Observation space
    :param action_space: Action space
    :param lr_schedule: Learning rate schedule (could be constant)
    :param net_arch: The specification of the policy and value networks.
    :param activation_fn: Activation function
    :param use_sde: Whether to use State Dependent Exploration or not
    :param log_std_init: Initial value for the log standard deviation
    :param use_expln: Use ``expln()`` function instead of ``exp()`` when using gSDE to ensure
        a positive standard deviation (cf paper). It allows to keep variance
        above zero and prevent it from growing too fast. In practice, ``exp()`` is usually enough.
    :param clip_mean: Clip the mean output when using gSDE to avoid numerical instability.
    :param features_extractor_class: Features extractor to use.
    :param features_extractor_kwargs: Keyword arguments
        to pass to the features extractor.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    :param optimizer_class: The optimizer to use,
        ``th.optim.Adam`` by default
    :param optimizer_kwargs: Additional keyword arguments,
        excluding the learning rate, to pass to the optimizer
    :param n_critics: Number of critic networks to create.
    :param share_features_extractor: Whether to share or not the features extractor
        between the actor and the critic (this saves computation time)
    """

    actor: Actor
    critic: ContinuousCritic
    critic_target: ContinuousCritic

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        lr_schedule: Schedule,
        net_arch: Optional[Union[list[int], dict[str, list[int]]]] = None,
        activation_fn: type[nn.Module] = nn.ReLU,
        use_sde: bool = False,
        log_std_init: float = -3,
        use_expln: bool = False,
        clip_mean: float = 2.0,
        features_extractor_class: type[BaseFeaturesExtractor] = FlattenExtractor,
        features_extractor_kwargs: Optional[dict[str, Any]] = None,
        normalize_images: bool = True,
        optimizer_class: type[th.optim.Optimizer] = th.optim.Adam,
        optimizer_kwargs: Optional[dict[str, Any]] = None,
        n_critics: int = 2,
        share_features_extractor: bool = False,
        post_linear_modules: Optional[list[type[nn.Module]]] = None,
        standard_gauss_init: bool = False,
        adapter_kwargs: Optional[dict[str, Any]] = None,
    ):
        super().__init__(
            observation_space,
            action_space,
            features_extractor_class,
            features_extractor_kwargs,
            optimizer_class=optimizer_class,
            optimizer_kwargs=optimizer_kwargs,
            squash_output=True,
            normalize_images=normalize_images,
        )

        if net_arch is None:
            net_arch = [256, 256]

        actor_arch, critic_arch = get_actor_critic_arch(net_arch)

        self.net_arch = net_arch
        self.activation_fn = activation_fn
        self.adapter_kwargs = adapter_kwargs
        self.net_args = {
            "observation_space": self.observation_space,
            "action_space": self.action_space,
            "net_arch": actor_arch,
            "activation_fn": self.activation_fn,
            "normalize_images": normalize_images,
            "post_linear_modules": post_linear_modules,
        }
        self.actor_kwargs = self.net_args.copy()

        sde_kwargs = {
            "use_sde": use_sde,
            "log_std_init": log_std_init,
            "use_expln": use_expln,
            "clip_mean": clip_mean,
            "standard_gauss_init": standard_gauss_init,
            "adapter_kwargs": adapter_kwargs,
        }
        self.actor_kwargs.update(sde_kwargs)
        self.critic_kwargs = self.net_args.copy()
        self.critic_kwargs.update(
            {
                "n_critics": n_critics,
                "net_arch": critic_arch,
                "share_features_extractor": share_features_extractor,
            }
        )

        self.share_features_extractor = share_features_extractor

        self._build(lr_schedule)

    def _build(self, lr_schedule: Schedule) -> None:
        self.actor = self.make_actor()
        self.actor.optimizer = self.optimizer_class(
            self.actor.parameters(),
            lr=lr_schedule(1),  # type: ignore[call-arg]
            **self.optimizer_kwargs,
        )

        if self.share_features_extractor:
            self.critic = self.make_critic(features_extractor=self.actor.features_extractor)
            # Do not optimize the shared features extractor with the critic loss
            # otherwise, there are gradient computation issues
            critic_parameters = [param for name, param in self.critic.named_parameters() if "features_extractor" not in name]
        else:
            # Create a separate features extractor for the critic
            # this requires more memory and computation
            self.critic = self.make_critic(features_extractor=None)
            critic_parameters = list(self.critic.parameters())

        # Critic target should not share the features extractor with critic
        self.critic_target = self.make_critic(features_extractor=None)
        self.critic_target.load_state_dict(self.critic.state_dict())

        self.critic.optimizer = self.optimizer_class(
            critic_parameters,
            lr=lr_schedule(1),  # type: ignore[call-arg]
            **self.optimizer_kwargs,
        )

        # Target networks should always be in eval mode
        self.critic_target.set_training_mode(False)

    def _get_constructor_parameters(self) -> dict[str, Any]:
        data = super()._get_constructor_parameters()

        data.update(
            dict(
                net_arch=self.net_arch,
                activation_fn=self.net_args["activation_fn"],
                use_sde=self.actor_kwargs["use_sde"],
                log_std_init=self.actor_kwargs["log_std_init"],
                use_expln=self.actor_kwargs["use_expln"],
                clip_mean=self.actor_kwargs["clip_mean"],
                n_critics=self.critic_kwargs["n_critics"],
                lr_schedule=self._dummy_schedule,  # dummy lr schedule, not needed for loading policy alone
                optimizer_class=self.optimizer_class,
                optimizer_kwargs=self.optimizer_kwargs,
                features_extractor_class=self.features_extractor_class,
                features_extractor_kwargs=self.features_extractor_kwargs,
                adapter_kwargs=self.adapter_kwargs,
            )
        )
        return data

    def reset_noise(self, batch_size: int = 1) -> None:
        """
        Sample new weights for the exploration matrix, when using gSDE.

        :param batch_size:
        """
        self.actor.reset_noise(batch_size=batch_size)

    def make_actor(self, features_extractor: Optional[BaseFeaturesExtractor] = None) -> Actor:
        actor_kwargs = self._update_features_extractor(self.actor_kwargs, features_extractor)
        return Actor(**actor_kwargs).to(self.device)

    def make_critic(self, features_extractor: Optional[BaseFeaturesExtractor] = None) -> ContinuousCritic:
        critic_kwargs = self._update_features_extractor(self.critic_kwargs, features_extractor)
        return ContinuousCritic(**critic_kwargs).to(self.device)

    def forward(self, obs: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        return self._predict(obs, deterministic=deterministic)

    def _predict(self, observation: PyTorchObs, deterministic: bool = False) -> th.Tensor:
        return self.actor(observation, deterministic)

    def set_training_mode(self, mode: bool) -> None:
        """
        Put the policy in either training or evaluation mode.

        This affects certain modules, such as batch normalisation and dropout.

        :param mode: if true, set to training mode, else set to evaluation mode
        """
        self.actor.set_training_mode(mode)
        self.critic.set_training_mode(mode)
        self.training = mode


MlpPolicy = SACPolicy


class CnnPolicy(SACPolicy):
    """
    Policy class (with both actor and critic) for SAC.

    :param observation_space: Observation space
    :param action_space: Action space
    :param lr_schedule: Learning rate schedule (could be constant)
    :param net_arch: The specification of the policy and value networks.
    :param activation_fn: Activation function
    :param use_sde: Whether to use State Dependent Exploration or not
    :param log_std_init: Initial value for the log standard deviation
    :param use_expln: Use ``expln()`` function instead of ``exp()`` when using gSDE to ensure
        a positive standard deviation (cf paper). It allows to keep variance
        above zero and prevent it from growing too fast. In practice, ``exp()`` is usually enough.
    :param clip_mean: Clip the mean output when using gSDE to avoid numerical instability.
    :param features_extractor_class: Features extractor to use.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    :param optimizer_class: The optimizer to use,
        ``th.optim.Adam`` by default
    :param optimizer_kwargs: Additional keyword arguments,
        excluding the learning rate, to pass to the optimizer
    :param n_critics: Number of critic networks to create.
    :param share_features_extractor: Whether to share or not the features extractor
        between the actor and the critic (this saves computation time)
    """

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        lr_schedule: Schedule,
        net_arch: Optional[Union[list[int], dict[str, list[int]]]] = None,
        activation_fn: type[nn.Module] = nn.ReLU,
        use_sde: bool = False,
        log_std_init: float = -3,
        use_expln: bool = False,
        clip_mean: float = 2.0,
        features_extractor_class: type[BaseFeaturesExtractor] = NatureCNN,
        features_extractor_kwargs: Optional[dict[str, Any]] = None,
        normalize_images: bool = True,
        optimizer_class: type[th.optim.Optimizer] = th.optim.Adam,
        optimizer_kwargs: Optional[dict[str, Any]] = None,
        n_critics: int = 2,
        share_features_extractor: bool = False,
    ):
        super().__init__(
            observation_space,
            action_space,
            lr_schedule,
            net_arch,
            activation_fn,
            use_sde,
            log_std_init,
            use_expln,
            clip_mean,
            features_extractor_class,
            features_extractor_kwargs,
            normalize_images,
            optimizer_class,
            optimizer_kwargs,
            n_critics,
            share_features_extractor,
        )


class MultiInputPolicy(SACPolicy):
    """
    Policy class (with both actor and critic) for SAC.

    :param observation_space: Observation space
    :param action_space: Action space
    :param lr_schedule: Learning rate schedule (could be constant)
    :param net_arch: The specification of the policy and value networks.
    :param activation_fn: Activation function
    :param use_sde: Whether to use State Dependent Exploration or not
    :param log_std_init: Initial value for the log standard deviation
    :param use_expln: Use ``expln()`` function instead of ``exp()`` when using gSDE to ensure
        a positive standard deviation (cf paper). It allows to keep variance
        above zero and prevent it from growing too fast. In practice, ``exp()`` is usually enough.
    :param clip_mean: Clip the mean output when using gSDE to avoid numerical instability.
    :param features_extractor_class: Features extractor to use.
    :param normalize_images: Whether to normalize images or not,
         dividing by 255.0 (True by default)
    :param optimizer_class: The optimizer to use,
        ``th.optim.Adam`` by default
    :param optimizer_kwargs: Additional keyword arguments,
        excluding the learning rate, to pass to the optimizer
    :param n_critics: Number of critic networks to create.
    :param share_features_extractor: Whether to share or not the features extractor
        between the actor and the critic (this saves computation time)
    """

    def __init__(
        self,
        observation_space: spaces.Space,
        action_space: spaces.Box,
        lr_schedule: Schedule,
        net_arch: Optional[Union[list[int], dict[str, list[int]]]] = None,
        activation_fn: type[nn.Module] = nn.ReLU,
        use_sde: bool = False,
        log_std_init: float = -3,
        use_expln: bool = False,
        clip_mean: float = 2.0,
        features_extractor_class: type[BaseFeaturesExtractor] = CombinedExtractor,
        features_extractor_kwargs: Optional[dict[str, Any]] = None,
        normalize_images: bool = True,
        optimizer_class: type[th.optim.Optimizer] = th.optim.Adam,
        optimizer_kwargs: Optional[dict[str, Any]] = None,
        n_critics: int = 2,
        share_features_extractor: bool = False,
    ):
        super().__init__(
            observation_space,
            action_space,
            lr_schedule,
            net_arch,
            activation_fn,
            use_sde,
            log_std_init,
            use_expln,
            clip_mean,
            features_extractor_class,
            features_extractor_kwargs,
            normalize_images,
            optimizer_class,
            optimizer_kwargs,
            n_critics,
            share_features_extractor,
        )
