"""
Transformer denoising network for low-dimensional diffusion policies.

This module matches the DPPO diffusion network interface used by
DiffusionModel/DiffusionEval: forward(x, time, cond) -> tensor shaped like x.
It is adapted from the official Diffusion Policy TransformerForDiffusion, but
uses DPPO's cond dict format.
"""

import logging
from typing import Optional, Union

import torch
import torch.nn as nn

from model.diffusion.modules import SinusoidalPosEmb

log = logging.getLogger(__name__)


class DiffusionTransformer(nn.Module):
    def __init__(
        self,
        action_dim: int,
        horizon_steps: int,
        cond_dim: int,
        n_layer: int = 4,
        n_head: int = 4,
        n_emb: int = 128,
        p_drop_emb: float = 0.0,
        p_drop_attn: float = 0.1,
        activation: str = "gelu",
        causal_attn: bool = True,
        n_cond_layers: int = 0,
        **unused_kwargs,
    ):
        super().__init__()
        self.action_dim = action_dim
        self.horizon_steps = horizon_steps
        self.cond_dim = cond_dim
        self.n_emb = n_emb

        self.input_emb = nn.Linear(action_dim, n_emb)
        self.pos_emb = nn.Parameter(torch.zeros(1, horizon_steps, n_emb))
        self.drop = nn.Dropout(p_drop_emb)

        self.time_emb = SinusoidalPosEmb(n_emb)
        self.cond_obs_emb = nn.Linear(cond_dim, n_emb)
        # Condition memory is [time token, flattened observation token].
        self.cond_pos_emb = nn.Parameter(torch.zeros(1, 2, n_emb))

        if n_cond_layers > 0:
            encoder_layer = nn.TransformerEncoderLayer(
                d_model=n_emb,
                nhead=n_head,
                dim_feedforward=4 * n_emb,
                dropout=p_drop_attn,
                activation=activation,
                batch_first=True,
                norm_first=True,
            )
            self.encoder = nn.TransformerEncoder(
                encoder_layer=encoder_layer,
                num_layers=n_cond_layers,
            )
        else:
            self.encoder = nn.Sequential(
                nn.Linear(n_emb, 4 * n_emb),
                nn.Mish(),
                nn.Linear(4 * n_emb, n_emb),
            )

        decoder_layer = nn.TransformerDecoderLayer(
            d_model=n_emb,
            nhead=n_head,
            dim_feedforward=4 * n_emb,
            dropout=p_drop_attn,
            activation=activation,
            batch_first=True,
            norm_first=True,
        )
        self.decoder = nn.TransformerDecoder(
            decoder_layer=decoder_layer,
            num_layers=n_layer,
        )

        if causal_attn:
            mask = torch.triu(torch.ones(horizon_steps, horizon_steps), diagonal=1)
            mask = mask.float().masked_fill(mask == 1, float("-inf"))
            self.register_buffer("mask", mask)
        else:
            self.mask = None

        self.ln_f = nn.LayerNorm(n_emb)
        self.head = nn.Linear(n_emb, action_dim)

        self.apply(self._init_weights)
        nn.init.normal_(self.pos_emb, mean=0.0, std=0.02)
        nn.init.normal_(self.cond_pos_emb, mean=0.0, std=0.02)
        log.info(
            "Number of DiffusionTransformer parameters: %e",
            sum(p.numel() for p in self.parameters()),
        )

    def _init_weights(self, module):
        if isinstance(module, nn.Linear):
            nn.init.normal_(module.weight, mean=0.0, std=0.02)
            if module.bias is not None:
                nn.init.zeros_(module.bias)
        elif isinstance(module, nn.MultiheadAttention):
            for name in ("in_proj_weight", "q_proj_weight", "k_proj_weight", "v_proj_weight"):
                weight = getattr(module, name, None)
                if weight is not None:
                    nn.init.normal_(weight, mean=0.0, std=0.02)
            for name in ("in_proj_bias", "bias_k", "bias_v"):
                bias = getattr(module, name, None)
                if bias is not None:
                    nn.init.zeros_(bias)
        elif isinstance(module, nn.LayerNorm):
            nn.init.ones_(module.weight)
            nn.init.zeros_(module.bias)

    def _flatten_state(self, cond: dict, batch_size: int) -> torch.Tensor:
        if "state" not in cond:
            raise KeyError("DiffusionTransformer currently expects cond['state'] for low-dimensional observations")
        state = cond["state"].reshape(batch_size, -1)
        if state.shape[-1] != self.cond_dim:
            raise RuntimeError(
                f"Expected flattened cond dim {self.cond_dim}, got {state.shape[-1]}. "
                "Check obs_dim, cond_steps, and the observation wrapper."
            )
        return state

    def _adapter_delta(
        self,
        hidden: torch.Tensor,
        adapter_feature: Optional[torch.Tensor],
        adapter_gate: Optional[torch.Tensor],
        adapter_scale: float,
    ) -> Optional[torch.Tensor]:
        if adapter_feature is None:
            return None

        if adapter_feature.ndim == 2:
            adapter_feature = adapter_feature.unsqueeze(1)
        if adapter_feature.ndim != 3 or adapter_feature.shape[-1] != self.n_emb:
            raise ValueError(
                f"Expected adapter_feature shape (B, steps, {self.n_emb}), "
                f"got {tuple(adapter_feature.shape)}"
            )
        if adapter_feature.shape[1] == 1:
            adapter_feature = adapter_feature.expand(-1, self.horizon_steps, -1)
        elif adapter_feature.shape[1] != self.horizon_steps:
            raise ValueError(
                f"Expected 1 or {self.horizon_steps} adapter feature steps, "
                f"got {adapter_feature.shape[1]}"
            )

        if adapter_gate is None:
            adapter_gate = torch.ones(
                (*adapter_feature.shape[:-1], 1),
                device=hidden.device,
                dtype=hidden.dtype,
            )
        else:
            if adapter_gate.ndim == 2:
                adapter_gate = adapter_gate.unsqueeze(1)
            if adapter_gate.ndim != 3 or adapter_gate.shape[-1] != 1:
                raise ValueError(
                    f"Expected adapter_gate shape (B, steps, 1), got {tuple(adapter_gate.shape)}"
                )
            if adapter_gate.shape[1] == 1:
                adapter_gate = adapter_gate.expand(-1, self.horizon_steps, -1)
            elif adapter_gate.shape[1] != self.horizon_steps:
                raise ValueError(
                    f"Expected 1 or {self.horizon_steps} adapter gate steps, "
                    f"got {adapter_gate.shape[1]}"
                )

        if adapter_feature.shape[:2] != hidden.shape[:2]:
            raise ValueError(
                f"Adapter tokens {tuple(adapter_feature.shape[:2])} do not match "
                f"hidden tokens {tuple(hidden.shape[:2])}"
            )
        return (
            float(adapter_scale)
            * adapter_gate.to(device=hidden.device, dtype=hidden.dtype)
            * torch.tanh(adapter_feature.to(device=hidden.device, dtype=hidden.dtype))
        )

    def _decode_with_adapter(
        self,
        action_tokens: torch.Tensor,
        memory: torch.Tensor,
        adapter_delta: Optional[torch.Tensor],
    ) -> torch.Tensor:
        if adapter_delta is None:
            return self.decoder(tgt=action_tokens, memory=memory, tgt_mask=self.mask)

        hidden = action_tokens
        for layer in self.decoder.layers:
            hidden = layer(hidden, memory, tgt_mask=self.mask)
            hidden = hidden + adapter_delta
        if self.decoder.norm is not None:
            hidden = self.decoder.norm(hidden)
        return hidden

    def forward(
        self,
        x: torch.Tensor,
        time: Union[torch.Tensor, float, int],
        cond: Optional[dict] = None,
        **kwargs,
    ) -> torch.Tensor:
        """
        Args:
            x: noisy action chunk, shape (B, horizon_steps, action_dim)
            time: diffusion timestep, shape (B,) or scalar
            cond: DPPO condition dict containing state with shape (B, To, Do)

        Returns:
            Predicted noise or denoised action, shape (B, horizon_steps, action_dim)
        """
        if cond is None:
            raise ValueError("DiffusionTransformer requires a condition dict")
        batch_size, horizon, action_dim = x.shape
        if horizon != self.horizon_steps or action_dim != self.action_dim:
            raise RuntimeError(
                f"Expected x shape (B, {self.horizon_steps}, {self.action_dim}), got {tuple(x.shape)}"
            )

        if not torch.is_tensor(time):
            time = torch.tensor([time], dtype=torch.long, device=x.device)
        elif time.ndim == 0:
            time = time[None].to(x.device)
        time = time.to(device=x.device).expand(batch_size)

        time_token = self.time_emb(time).unsqueeze(1)
        state_token = self.cond_obs_emb(self._flatten_state(cond, batch_size)).unsqueeze(1)
        cond_tokens = torch.cat([time_token, state_token], dim=1)
        cond_tokens = self.drop(cond_tokens + self.cond_pos_emb[:, : cond_tokens.shape[1]])
        memory = self.encoder(cond_tokens)

        action_tokens = self.input_emb(x)
        action_tokens = self.drop(action_tokens + self.pos_emb[:, :horizon])
        adapter_delta = self._adapter_delta(
            action_tokens,
            cond.get("adapter_feature"),
            cond.get("adapter_gate"),
            cond.get("adapter_scale", 0.0),
        )
        out = self._decode_with_adapter(action_tokens, memory, adapter_delta)
        out = self.head(self.ln_f(out))
        return out
